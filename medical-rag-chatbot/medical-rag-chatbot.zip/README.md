# Medical RAG Chatbot

Production-ready RAG chatbot template.